<?php
    $conn = new mysqli('localhost', 'root', '', 'fcomtest');

    if ($conn->connect_error){
        die("Connection Failed: " . $conn->connect_error);
    }
?>